@echo off
echo.
echo  =============================================
echo   MARKET SCANNER PRO — Instalador
echo  =============================================
echo.

REM Criar pasta se nao existir
if not exist "C:\Users\Nuno Gueifao\Desktop\Python\scanner" (
    mkdir "C:\Users\Nuno Gueifao\Desktop\Python\scanner"
)
if not exist "C:\Users\Nuno Gueifao\Desktop\Python\scanner\static" (
    mkdir "C:\Users\Nuno Gueifao\Desktop\Python\scanner\static"
)

REM Copiar ficheiros
echo  A copiar app.py...
copy /Y "%~dp0app.py" "C:\Users\Nuno Gueifao\Desktop\Python\scanner\app.py"

echo  A copiar index.html...
copy /Y "%~dp0index.html" "C:\Users\Nuno Gueifao\Desktop\Python\scanner\static\index.html"

echo.
echo  Instalacao completa!
echo  Para correr o scanner:
echo.
echo  cd C:\Users\Nuno Gueifao\Desktop\Python\scanner
echo  python app.py
echo.
pause
